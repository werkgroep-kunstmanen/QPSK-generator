quartus_pgm -c USB-Blaster qpskgen.cdf
