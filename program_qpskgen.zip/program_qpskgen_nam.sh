# qpskgenerator Noaa20, Aqua and Metop
quartus_pgm -c USB-Blaster qpskgen_nam.cdf
