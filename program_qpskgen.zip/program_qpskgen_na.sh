# qpskgenerator Noaa20 and Aqua
quartus_pgm -c USB-Blaster qpskgen_na.cdf
